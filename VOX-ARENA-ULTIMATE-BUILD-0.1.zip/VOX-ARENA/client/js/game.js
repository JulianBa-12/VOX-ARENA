import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";

const WEAPONS = [
  {name:"PULSE RIFLE",mag:24,reserve:96,damage:34,delay:260,reload:1350,color:0x00d9ff},
  {name:"VOLT SMG",mag:36,reserve:144,damage:17,delay:95,reload:1150,color:0x287bff},
  {name:"HEAVY BLASTER",mag:8,reserve:32,damage:78,delay:650,reload:1900,color:0x914dff}
];

export function startGame({canvas,map,onExit,onToast}) {
  let active = true, locked = false, health = 100, kills = 0, weaponIndex = 0, ammo = WEAPONS.map(w=>w.mag);
  let lastShot = 0, reloading = false, elapsed = 0, last = performance.now(), jumpVelocity = 0, grounded = true, y = 1.7;
  const keys = new Set(), bots = [], clockStart = performance.now();
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x07111e); scene.fog = new THREE.Fog(0x07111e,22,85);
  const camera = new THREE.PerspectiveCamera(78,innerWidth/innerHeight,.1,140);
  camera.position.set(0,1.7,8);
  const renderer = new THREE.WebGLRenderer({canvas,antialias:true});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.7)); renderer.setSize(innerWidth,innerHeight); renderer.shadowMap.enabled=true;
  scene.add(new THREE.HemisphereLight(0x9edfff,0x182239,2));
  const keyLight = new THREE.DirectionalLight(0x9bdfff,2.2); keyLight.position.set(8,15,8); keyLight.castShadow=true; scene.add(keyLight);
  const floorMat = new THREE.MeshStandardMaterial({color:0x172a40,metalness:.55,roughness:.72});
  const floor = new THREE.Mesh(new THREE.BoxGeometry(62,1,62),floorMat); floor.position.y=-.5; floor.receiveShadow=true; scene.add(floor);
  const grid = new THREE.GridHelper(62,62,0x00a9c7,0x29415a); grid.position.y=.02; scene.add(grid);
  const obstacles=[];
  const theme = map === "IRON FOUNDRY" ? 0x526477 : map === "SKY CITADEL" ? 0x374c7a : map === "REACTOR CORE" ? 0x314d58 : 0x176078;
  function block(x,y,z,sx,sy,sz,color=theme,emissive=0x000000) {
    const mesh=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),new THREE.MeshStandardMaterial({color,metalness:.48,roughness:.55,emissive,emissiveIntensity:.7}));
    mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;scene.add(mesh);obstacles.push({x,z,sx,sz,sy});return mesh;
  }
  // Distinct arena silhouettes with central lanes, cover and raised platforms.
  block(0,2,-19,18,4,2,0x163d58,0x003344); block(-19,2,0,2,4,18); block(19,2,0,2,4,18);
  block(0,1.5,19,18,3,2); block(-8,1.1,-7,4,2.2,4,0x24516b,0x002a38); block(8,1.1,7,4,2.2,4,0x24516b,0x002a38);
  block(-8,2.7,7,2.5,5.4,2.5); block(8,2.7,-7,2.5,5.4,2.5);
  block(0,.7,0,7,1.4,3,0x1d4962,0x003d4b);
  for(let i=-2;i<=2;i++) { block(i*5,0.6,-13,2.2,1.2,2.2,0x1b344b); block(i*5,0.6,13,2.2,1.2,2.2,0x1b344b); }
  // Neon rails
  for(const [x,z,sx,sz] of [[0,-18,17,.08],[0,18,17,.08],[-18,0,.08,17],[18,0,.08,17]]) {
    const m=new THREE.Mesh(new THREE.BoxGeometry(sx,.07,sz),new THREE.MeshBasicMaterial({color:0x00d9ff}));m.position.set(x,.06,z);scene.add(m);
  }
  // Weapon silhouette attached to camera
  const weaponGroup=new THREE.Group();camera.add(weaponGroup);scene.add(camera);
  const gun=new THREE.Mesh(new THREE.BoxGeometry(.22,.18,.65),new THREE.MeshStandardMaterial({color:0x233d55,metalness:.8,roughness:.3,emissive:0x00384b}));
  gun.position.set(.34,-.28,-.65);weaponGroup.add(gun);
  const barrel=new THREE.Mesh(new THREE.BoxGeometry(.09,.09,.42),new THREE.MeshStandardMaterial({color:0x7894a8,metalness:.9}));barrel.position.set(.34,-.23,-1.12);weaponGroup.add(barrel);
  const glow=new THREE.PointLight(0x00d9ff,1,3);glow.position.set(.34,-.22,-1.2);weaponGroup.add(glow);

  const botMat = new THREE.MeshStandardMaterial({color:0xe15b78,metalness:.35,roughness:.5});
  function spawnBot(bot) {
    bot.group.position.set((Math.random()-.5)*30,0,(Math.random()-.5)*30);
    if(bot.group.position.length()<10) bot.group.position.x+=14;
    bot.hp=100;bot.cool=Math.random()*1.3;bot.strafe=Math.random()>.5?1:-1;
  }
  for(let i=0;i<4;i++){
    const g=new THREE.Group();
    const body=new THREE.Mesh(new THREE.BoxGeometry(.8,1.1,.5),botMat);body.position.y=1.1;g.add(body);
    const head=new THREE.Mesh(new THREE.BoxGeometry(.62,.62,.62),new THREE.MeshStandardMaterial({color:[0x9e6cff,0xe6a54b,0x4ad6bd,0xd66ca8][i]}));head.position.y=2;g.add(head);
    const eye=new THREE.Mesh(new THREE.BoxGeometry(.32,.07,.04),new THREE.MeshBasicMaterial({color:0x00f0ff}));eye.position.set(0,2.02,-.33);g.add(eye);
    scene.add(g);const bot={group:g,hp:100,cool:0,strafe:1};spawnBot(bot);bots.push(bot);
  }
  const raycaster=new THREE.Raycaster();const center=new THREE.Vector2(0,0);
  let yaw=0,pitch=0;
  function pointerLock(){canvas.requestPointerLock?.();}
  canvas.addEventListener("click",pointerLock);
  const onLock=()=>{locked=document.pointerLockElement===canvas;$("#game-hint").textContent=locked?"ESC TO RELEASE MOUSE":"CLICK TO CAPTURE MOUSE";};
  function $(id){return document.querySelector(id);}
  document.addEventListener("pointerlockchange",onLock);
  const onMouse=e=>{if(!locked)return;yaw-=e.movementX*.0022;pitch-=e.movementY*.0022;pitch=Math.max(-1.35,Math.min(1.35,pitch));};
  document.addEventListener("mousemove",onMouse);
  const onDown=e=>{if(e.button===0&&locked)shoot();};document.addEventListener("mousedown",onDown);
  const onKeyDown=e=>{keys.add(e.code);if(["Space","ArrowUp","ArrowDown"].includes(e.code))e.preventDefault();
    if(e.code==="Digit1")switchWeapon(0);if(e.code==="Digit2")switchWeapon(1);if(e.code==="Digit3")switchWeapon(2);
    if(e.code==="KeyR")reload();if(e.code==="Space"&&grounded){jumpVelocity=7.5;grounded=false;}
  };
  const onKeyUp=e=>keys.delete(e.code);document.addEventListener("keydown",onKeyDown);document.addEventListener("keyup",onKeyUp);
  function switchWeapon(i){weaponIndex=i;const w=WEAPONS[i];gun.material.color.setHex([0x233d55,0x244a77,0x49315f][i]);glow.color.setHex(w.color);updateHud();}
  function updateHud(){
    const w=WEAPONS[weaponIndex];$("#weapon-name").textContent=w.name;$("#ammo").textContent=ammo[weaponIndex];$("#reserve").textContent=w.reserve;
    $("#health").textContent=health;$("#health-bar").style.width=health+"%";$("#kills").textContent=kills;$("#bot-count").textContent="HOSTILES "+bots.length;
  }
  function reload(){if(reloading||ammo[weaponIndex]===WEAPONS[weaponIndex].mag)return;reloading=true;const w=WEAPONS[weaponIndex];onToast("RELOADING");setTimeout(()=>{if(!active)return;ammo[weaponIndex]=w.mag;w.reserve=Math.max(0,w.reserve-w.mag);reloading=false;updateHud();},w.reload);}
  function shoot(){
    const now=performance.now(),w=WEAPONS[weaponIndex];if(now-lastShot<w.delay||reloading)return;
    if(ammo[weaponIndex]<=0){reload();return;}lastShot=now;ammo[weaponIndex]--;updateHud();
    raycaster.setFromCamera(center,camera);const hits=raycaster.intersectObjects(bots.map(b=>b.group),true);
    if(hits.length){let target=bots.find(b=>b.group===hits[0].object.parent||b.group===hits[0].object.parent?.parent);if(!target)target=bots.find(b=>b.group===hits[0].object.parent?.parent?.parent);if(target){target.hp-=w.damage;if(target.hp<=0){kills++;spawnBot(target);onToast("TARGET ELIMINATED");}}}
    gun.position.z=-.58;setTimeout(()=>{if(active)gun.position.z=-.65;},55);updateHud();
  }
  function collides(x,z){return obstacles.some(o=>Math.abs(x-o.x)<o.sx/2+.45&&Math.abs(z-o.z)<o.sz/2+.45&&o.sy>1.8);}
  function botUpdate(dt){
    for(const b of bots){
      const p=b.group.position,dx=camera.position.x-p.x,dz=camera.position.z-p.z,dist=Math.hypot(dx,dz);
      if(dist>2.6){const speed=2.4;const nx=p.x+dx/dist*speed*dt+b.strafe*(-dz/dist)*.8*dt;const nz=p.z+dz/dist*speed*dt+b.strafe*(dx/dist)*.8*dt;if(!collides(nx,nz)){p.x=nx;p.z=nz;}else b.strafe*=-1;}
      b.group.lookAt(camera.position.x,1,camera.position.z);b.cool-=dt;
      if(dist<18&&b.cool<=0){b.cool=1.4+Math.random()*1.1;if(Math.random()<.22){health=Math.max(0,health-7);updateHud();if(health===0){health=100;camera.position.set(0,1.7,8);onToast("RESPAWN");}}}
    }
  }
  function animate(now){
    if(!active)return;requestAnimationFrame(animate);const dt=Math.min((now-last)/1000,.04);last=now;elapsed=(now-clockStart)/1000;
    const remaining=Math.max(0,600-elapsed);$("#timer").textContent=String(Math.floor(remaining/60)).padStart(2,"0")+":"+String(Math.floor(remaining%60)).padStart(2,"0");
    if(remaining<=0){onToast("MATCH COMPLETE");active=false;setTimeout(onExit,1600);return;}
    const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw)),right=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));
    const move=new THREE.Vector3();if(keys.has("KeyW"))move.add(forward);if(keys.has("KeyS"))move.sub(forward);if(keys.has("KeyD"))move.add(right);if(keys.has("KeyA"))move.sub(right);
    if(move.lengthSq()>0)move.normalize();const speed=keys.has("ControlLeft")?2.2:keys.has("ShiftLeft")?9:5.8;
    const nx=camera.position.x+move.x*speed*dt,nz=camera.position.z+move.z*speed*dt;
    if(!collides(nx,camera.position.z))camera.position.x=THREE.MathUtils.clamp(nx,-29,29);
    if(!collides(camera.position.x,nz))camera.position.z=THREE.MathUtils.clamp(nz,-29,29);
    if(!grounded){jumpVelocity-=18*dt;y+=jumpVelocity*dt;if(y<=1.7){y=1.7;jumpVelocity=0;grounded=true;}}
    camera.position.y=y;camera.rotation.order="YXZ";camera.rotation.y=yaw;camera.rotation.x=pitch;
    weaponGroup.position.y=Math.sin(now*.008)*.008*(move.length()>0?2:1);
    botUpdate(dt);renderer.render(scene,camera);
  }
  function resize(){camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);}
  window.addEventListener("resize",resize);
  const exitHandler=()=>{if(!active)return;active=false;document.exitPointerLock?.();document.removeEventListener("pointerlockchange",onLock);document.removeEventListener("mousemove",onMouse);document.removeEventListener("mousedown",onDown);document.removeEventListener("keydown",onKeyDown);document.removeEventListener("keyup",onKeyUp);window.removeEventListener("resize",resize);renderer.dispose();onExit();};
  $("#leave-game").onclick=exitHandler;
  updateHud();requestAnimationFrame(animate);
}
