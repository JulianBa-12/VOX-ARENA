import { startGame } from "./game.js";

const $ = s => document.querySelector(s);
const socket = window.io ? io() : null;
let authMode = "login";
let currentUser = null;
let currentPage = "play";

function toast(message) {
  const el = $("#toast"); if (!el) return;
  el.textContent = message; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 1800);
}
function showPage(page) {
  currentPage = page;
  $("#menu").classList.toggle("hidden", page !== "play");
  $("#subpage").classList.toggle("hidden", page === "play");
  document.querySelectorAll(".nav").forEach(b => b.classList.toggle("active", b.dataset.page === page));
  if (page !== "play") {
    $("#sub-title").textContent = page.toUpperCase();
    const content = {
      inventory: `<div class="eyebrow">OPERATIVE LOADOUT</div><p>Your persistent inventory system is scheduled for Phase 3. The current build uses the Pulse Rifle, Volt SMG and Heavy Blaster as gameplay test weapons.</p><div class="placeholder-grid"><div class="placeholder-item"><b>PULSE RIFLE</b>Equipped · Common</div><div class="placeholder-item"><b>VOLT SMG</b>Unlocked for testing</div><div class="placeholder-item"><b>HEAVY BLASTER</b>Unlocked for testing</div></div>`,
      store: `<div class="eyebrow">ARMORY EXCHANGE</div><p>The store interface is reserved. Purchases and currency are not enabled in Build 0.1.</p>`,
      profile: `<div class="eyebrow">PILOT RECORD</div><p>Sign in to establish an account. Persistent match statistics and progression will be connected in a later phase.</p><div class="placeholder-grid"><div class="placeholder-item"><b>LEVEL</b>01</div><div class="placeholder-item"><b>XP</b>0</div><div class="placeholder-item"><b>PLAYTIME</b>0 H</div></div>`,
      leaderboard: `<div class="eyebrow">GLOBAL RANKING</div><p>Leaderboard data is not yet connected. This panel will display verified server-side statistics.</p>`,
      settings: `<div class="eyebrow">CLIENT CONFIGURATION</div><p>Basic settings are being added in a later phase. Current controls: WASD, mouse, Space, Shift, Ctrl, R and 1–3.</p>`
    };
    $("#sub-content").innerHTML = content[page] || "";
  }
}
document.querySelectorAll("[data-page]").forEach(b => b.addEventListener("click", () => showPage(b.dataset.page)));
$("#back").addEventListener("click", () => showPage("play"));
$("#deploy").addEventListener("click", () => {
  $("#menu").classList.add("hidden"); $("#subpage").classList.add("hidden"); $("#game").classList.remove("hidden");
  startGame({ canvas: $("#game-canvas"), map: $("#map-select").value, onExit: () => {
    $("#game").classList.add("hidden"); $("#menu").classList.remove("hidden"); showPage("play");
  }, onToast: toast });
});

$("#account-btn").addEventListener("click", () => $("#auth-modal").classList.remove("hidden"));
document.querySelectorAll("[data-close]").forEach(b => b.addEventListener("click", () => $("#" + b.dataset.close).classList.add("hidden")));
document.querySelectorAll("[data-auth]").forEach(b => b.addEventListener("click", () => {
  authMode = b.dataset.auth;
  document.querySelectorAll("[data-auth]").forEach(x => x.classList.toggle("selected", x === b));
  $("#auth-form button[type=submit]").textContent = authMode.toUpperCase() + " ↗";
}));
$("#auth-form").addEventListener("submit", async e => {
  e.preventDefault(); $("#auth-error").textContent = "";
  const fd = new FormData(e.currentTarget);
  try {
    const res = await fetch("/api/" + authMode, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({username:fd.get("username"),password:fd.get("password")}) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || "Request failed");
    setUser(data.user); $("#auth-modal").classList.add("hidden");
  } catch(err) { $("#auth-error").textContent = err.message; }
});
function setUser(user) {
  currentUser = user; $("#account-name").textContent = user.username.toUpperCase(); $("#profile-name").textContent = user.username.toUpperCase();
  $("#account-btn").textContent = "LOGOUT";
  $("#account-btn").onclick = async () => { await fetch("/api/logout",{method:"POST"}); location.reload(); };
}
fetch("/api/me").then(r=>r.json()).then(d=>{ if(d.user) setUser(d.user); }).catch(()=>{});

$("#create-room").addEventListener("click", () => {
  const id = "room-" + Math.random().toString(36).slice(2,7);
  socket?.emit("room:join", { roomId:id, roomName:"New Arena" });
  toast("Room created: " + id);
});
socket?.on("presence", data => {
  $("#online-count").textContent = data.players;
  $("#room-count").textContent = data.rooms.length;
  $("#room-list").innerHTML = data.rooms.length ? data.rooms.map(r=>`<div class="room-entry"><b>${escapeHtml(r.name)} · ${escapeHtml(r.id)}</b><span>${r.players}/${r.max} OPERATIVES</span></div>`).join("") : '<div class="empty">No active rooms detected.</div>';
});
function escapeHtml(s) { return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
