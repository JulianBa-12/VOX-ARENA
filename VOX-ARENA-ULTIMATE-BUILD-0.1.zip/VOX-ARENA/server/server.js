const path = require("path");
const fs = require("fs");
const http = require("http");
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const { Server } = require("socket.io");

const ROOT = path.join(__dirname, "..");
const DATA = path.join(__dirname, "data");
const UPLOADS = path.join(ROOT, "uploads");
fs.mkdirSync(DATA, { recursive: true });
for (const dir of ["characters", "character-skins", "weapons", "weapon-textures", "maps", "drafts"]) {
  fs.mkdirSync(path.join(UPLOADS, dir), { recursive: true });
}

const db = new Database(path.join(DATA, "voxarena.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL COLLATE NOCASE UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'player',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS assets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id INTEGER NOT NULL,
  category TEXT NOT NULL,
  original_name TEXT NOT NULL,
  stored_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const sessionMiddleware = session({
  secret: process.env.SESSION_SECRET || "replace-this-local-development-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 1000 * 60 * 60 * 24 }
});
app.use(express.json({ limit: "32kb" }));
app.use(sessionMiddleware);
app.use(express.static(path.join(ROOT, "client")));
app.use("/uploads", express.static(UPLOADS));

io.engine.use(sessionMiddleware);
const rooms = new Map();
const online = new Map();

function auth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Login required" });
  next();
}
function admin(req, res, next) {
  if (!req.session.user || req.session.user.role !== "admin") return res.status(403).json({ error: "Administrator access required" });
  next();
}
function safeUser(user) {
  return { id: user.id, username: user.username, role: user.role };
}

app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));
app.post("/api/register", async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) return res.status(400).json({ error: "Username: 3–16 letters, numbers or underscores." });
  if (password.length < 8 || password.length > 72) return res.status(400).json({ error: "Password must contain 8–72 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(username, hash);
    const user = safeUser(db.prepare("SELECT id,username,role FROM users WHERE id=?").get(result.lastInsertRowid));
    req.session.user = user;
    res.json({ user });
  } catch {
    res.status(409).json({ error: "Username is already taken." });
  }
});
app.post("/api/login", async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const row = db.prepare("SELECT * FROM users WHERE username=?").get(username);
  if (!row || !(await bcrypt.compare(password, row.password_hash))) return res.status(401).json({ error: "Invalid username or password." });
  req.session.user = safeUser(row);
  res.json({ user: req.session.user });
});
app.post("/api/logout", auth, (req, res) => req.session.destroy(() => res.json({ ok: true })));

const multer = (() => {
  try { return require("multer"); } catch { return null; }
})();
if (multer) {
  const upload = multer({
    storage: multer.diskStorage({
      destination: (req, file, cb) => cb(null, path.join(UPLOADS, "drafts")),
      filename: (req, file, cb) => cb(null, `${Date.now()}-${Math.random().toString(16).slice(2)}${path.extname(file.originalname).toLowerCase()}`)
    }),
    limits: { fileSize: 30 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      const allowed = [".png", ".jpg", ".jpeg", ".glb", ".gltf", ".obj"];
      cb(allowed.includes(ext) ? null : new Error("Unsupported file extension"), allowed.includes(ext));
    }
  });
  app.post("/api/admin/assets", admin, upload.single("asset"), (req, res) => {
    if (!req.file) return res.status(400).json({ error: "No file uploaded." });
    const category = String(req.body.category || "other").slice(0, 32);
    const result = db.prepare("INSERT INTO assets(owner_id,category,original_name,stored_name) VALUES(?,?,?,?)")
      .run(req.session.user.id, category, req.file.originalname.slice(0, 180), req.file.filename);
    res.json({ id: result.lastInsertRowid, status: "draft", file: req.file.filename });
  });
} else {
  app.post("/api/admin/assets", admin, (req, res) => res.status(501).json({ error: "Install multer to enable uploads." }));
}
app.get("/api/admin/assets", admin, (req, res) => {
  res.json(db.prepare("SELECT id,category,original_name,status,created_at FROM assets ORDER BY id DESC").all());
});

io.on("connection", socket => {
  const user = socket.request.session?.user || { id: `guest-${socket.id}`, username: `Guest-${socket.id.slice(0,4)}` };
  online.set(socket.id, safeUser(user));
  socket.emit("presence", { players: online.size, rooms: [...rooms.entries()].map(([id, r]) => ({ id, name: r.name, players: r.players.size, max: 8 })) });

  socket.on("room:join", ({ roomId, roomName } = {}) => {
    roomId = String(roomId || "training").slice(0, 24);
    let room = rooms.get(roomId);
    if (!room) {
      room = { name: String(roomName || "Training Room").slice(0, 32), players: new Map() };
      rooms.set(roomId, room);
    }
    if (room.players.size >= 8 && !room.players.has(socket.id)) return socket.emit("room:error", "Room is full.");
    for (const old of socket.rooms) if (old !== socket.id) socket.leave(old);
    room.players.set(socket.id, { ...safeUser(user), x: 0, z: 0, yaw: 0 });
    socket.join(roomId);
    socket.data.roomId = roomId;
    io.to(roomId).emit("room:state", [...room.players.values()]);
    io.emit("presence", { players: online.size, rooms: [...rooms.entries()].map(([id, r]) => ({ id, name: r.name, players: r.players.size, max: 8 })) });
  });

  socket.on("player:state", state => {
    const room = rooms.get(socket.data.roomId);
    if (!room || !state) return;
    const p = room.players.get(socket.id);
    if (!p) return;
    p.x = Number(state.x) || 0; p.z = Number(state.z) || 0; p.yaw = Number(state.yaw) || 0;
    socket.to(socket.data.roomId).emit("player:update", { id: socket.id, ...p });
  });

  socket.on("chat:global", raw => {
    const message = String(raw || "").trim().slice(0, 240);
    if (message) io.emit("chat:global", { username: user.username, message, time: Date.now() });
  });
  socket.on("chat:room", raw => {
    const roomId = socket.data.roomId;
    const message = String(raw || "").trim().slice(0, 240);
    if (roomId && message) io.to(roomId).emit("chat:room", { username: user.username, message, time: Date.now() });
  });
  socket.on("disconnect", () => {
    online.delete(socket.id);
    const roomId = socket.data.roomId;
    const room = rooms.get(roomId);
    if (room) {
      room.players.delete(socket.id);
      if (!room.players.size) rooms.delete(roomId);
      else io.to(roomId).emit("room:state", [...room.players.values()]);
    }
    io.emit("presence", { players: online.size, rooms: [...rooms.entries()].map(([id, r]) => ({ id, name: r.name, players: r.players.size, max: 8 })) });
  });
});

const PORT = Number(process.env.PORT || 8080);
server.listen(PORT, "0.0.0.0", () => console.log(`VOX//ARENA running at http://localhost:${PORT}`));
