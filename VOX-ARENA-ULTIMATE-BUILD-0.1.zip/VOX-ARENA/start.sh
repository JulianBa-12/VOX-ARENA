#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is missing. Install Node.js 20 LTS or newer."
  exit 1
fi
npm install
npm start
