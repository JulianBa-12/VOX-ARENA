# VOX//ARENA — Build 0.1

A playable Phase-1 foundation for the VOX//ARENA project.

## Requirements
- Node.js 20 LTS or newer
- npm
- A modern browser with WebGL

## Linux installation
```bash
cd VOX-ARENA
chmod +x start.sh
./start.sh
```
Or:
```bash
npm install
npm start
```
Open **http://localhost:8080**.

## Current implementation
- Three.js first-person arena
- WASD movement, mouse look, jump, sprint, crouch
- Three fictional energy weapons with different magazine sizes/fire rates
- Raycast shooting, reload, health, respawn and HUD
- Four selectable arena themes (procedurally assembled layouts)
- Offline bot opponents with pursuit, strafing, firing and respawn
- 10-minute local match timer
- Express + Socket.IO server and live room/player presence foundation
- SQLite database initialization
- Registration/login endpoints with bcrypt password hashing and sessions
- Starter admin area protected by an administrator role
- Asset upload endpoint with extension/size checks and draft metadata

## Test controls
Click **BOT TRAINING**, then **DEPLOY**. Click the game canvas to lock the pointer.
- W/A/S/D: move
- Mouse: look
- Space: jump
- Shift: sprint
- Ctrl: crouch
- Left mouse: fire
- R: reload
- 1/2/3: switch weapon
- Esc: release mouse / pause pointer lock

## Initial administrator
For safety, no default administrator password is shipped.
Register a normal account, then promote it locally using the SQLite database only if you control the installation. A helper command is documented below.

To promote an account:
```bash
sqlite3 server/data/voxarena.db "UPDATE users SET role='admin' WHERE username='YOUR_USERNAME';"
```
If the `sqlite3` CLI is not installed, use any SQLite database browser.

## Important implementation status
This build is an honest playable foundation, not the complete final game described in the master prompt.

### Implemented in this build
- Offline first-person gameplay and bots
- Basic weapon/ammo/health systems
- Match timer and four procedural arena variants
- Backend account/session foundation
- Socket.IO room presence foundation
- Admin-gated upload endpoint and draft metadata

### Not yet complete
- Server-authoritative multiplayer movement, hit validation, damage and match outcomes
- Full lobby room creation/join UX and isolated room chat
- Persistent inventory/store purchases, XP progression and leaderboard UI
- Full character/weapon GLB/GLTF editor and material/UV workflow
- Minecraft skin UV mapping/editor
- Full map editor, spawn/collision authoring and publish pipeline
- Production-grade moderation, anti-cheat, deployment hardening and mobile touch controls
- Reference-video-specific pixel-accurate layout (the reference video was not included in this build context)

Uploaded assets are stored as drafts. Do not expose this development server publicly without additional security review.
